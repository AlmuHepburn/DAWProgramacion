public class MainCuadradoMagico {

    public static void main(String []args){

        CuadradoMagico cuadrado = new CuadradoMagico();

        cuadrado.pedirNumeroUsuario();

        cuadrado.generarCuadrado();

    }

}
